from kafka import KafkaProducer
import json
import time
import random

producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

while True:
    transaction = {
        "user_id": random.randint(1000, 9999),
        "amount": round(random.uniform(10, 1000), 2),
        "country": random.choice(["US", "IN", "UK", "RU", "CN"]),
        "timestamp": time.time()
    }
    producer.send("transactions", transaction)
    print("📤 Sent:", transaction)
    time.sleep(1)